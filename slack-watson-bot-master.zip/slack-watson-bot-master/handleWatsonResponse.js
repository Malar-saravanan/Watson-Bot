//------------------------------------------------------------------------------
// Copyright IBM Corp. 2017
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//------------------------------------------------------------------------------

var request = require('request');

module.exports = function () {
    return {
        "handleWatsonResponse": function (bot, message, clientType) {
            let customSlackMessage = false;
            let customFacebookMessage = false;
            let actionToBeInvoked = false;
            if (message.watsonData) {
                if (message.watsonData.output) {
                    if (message.watsonData.output.context) {
                        if (message.watsonData.output.context.slack) {
                            if (clientType == 'slack') {
                                customSlackMessage = true;
                            }
                        }
                        if (message.watsonData.output.context.facebook) {
                            if (clientType == 'facebook') {
                                customFacebookMessage = true;
                            }
                        }
                        if (message.watsonData.output.context.action) {
                            actionToBeInvoked = true;
                        }
                    }
                }
            }
            if (actionToBeInvoked == true) {
                bot.reply(message, message.watsonData.output.text.join('\n'));
                invokeAction(message.watsonData.output, bot, message);
            }
            else {
                if (customSlackMessage == true) {
                    bot.reply(message, message.watsonData.output.context.slack);
                } else {
                    if (customFacebookMessage == true) {
                        bot.reply(message, message.watsonData.output.context.facebook);
                    }
                    else {
                        bot.reply(message, message.watsonData.output.text[0]);
                    }
                }
            }
        }
    }
}

function invokeAction(watsonDataOutput, bot, message) {
    let actionName = watsonDataOutput.context.action.name;

    switch (actionName) {
        case 'lookupWeather':
            lookupWeather(watsonDataOutput, bot, message);
            break;

        case 'get-time':
            let answer = "It's " + new Date().getHours() + " o'clock and "
                + new Date().getMinutes() + " minutes";
            bot.reply(message, answer);
            break;

        default:
            bot.reply(message, "Sorry, I cannot execute what you've asked me to do");
    }
}


